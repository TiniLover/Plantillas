using System;
using System.Collections.Generic;

namespace Domain
{
    public enum LogDestination
    {
        File,
        SQL
    }

    public class Log
    {
        public string Message { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;

        public override string ToString()
        {
            return $"[{Timestamp:yyyy-MM-dd HH:mm:ss}] {Message}";
        }
    }

    public interface ILogger
    {
        void Store(Log log);
        List<Log> GetAll();
    }
}