using BLL;
using Domain;
using System.Collections.Generic;

namespace Services
{
    public class LoggingService
    {
        private readonly ILogManager _logManager;

        public LoggingService(ILogManager logManager)
        {
            _logManager = logManager;
        }

        public void Log(string message)
        {
            _logManager.LogMessage(message);
        }

        public IEnumerable<Log> GetAllLogs()
        {
            return _logManager.GetAllLogs();
        }
    }
}