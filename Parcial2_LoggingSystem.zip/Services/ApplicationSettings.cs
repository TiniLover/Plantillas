using System;
using System.IO;
using System.Collections.Generic;

namespace Services
{
    public static class ApplicationSettings
    {
        public static LogDestination LogDestination { get; private set; }
        public static string LogPath { get; private set; }

        public static void InitializeConfiguration()
        {
            var appSettingsPath = "appsettings.txt";
            var logsDirectory = "Logs";
            var defaultLogPath = Path.Combine(logsDirectory, "logs.txt");

            // Crear carpeta Logs si no existe
            if (!Directory.Exists(logsDirectory))
            {
                Directory.CreateDirectory(logsDirectory);
            }

            // Crear appsettings.txt si no existe o está vacío
            if (!File.Exists(appSettingsPath) || new FileInfo(appSettingsPath).Length == 0)
            {
                var defaultConfig = new List<string>
                {
                    "Destination=File",
                    $"Path={defaultLogPath}"
                };
                File.WriteAllLines(appSettingsPath, defaultConfig);
            }

            // Cargar configuración
            try
            {
                var lines = File.ReadAllLines(appSettingsPath);
                var settings = new Dictionary<string, string>();

                foreach (var line in lines)
                {
                    var parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length == 2)
                    {
                        settings[parts[0].Trim()] = parts[1].Trim();
                    }
                }

                if (settings.TryGetValue("Destination", out var destinationStr) &&
                    Enum.TryParse(destinationStr, out LogDestination destination))
                {
                    LogDestination = destination;
                }
                else
                {
                    LogDestination = LogDestination.File;
                }

                LogPath = settings.TryGetValue("Path", out var path) ? path : defaultLogPath;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error cargando configuración: {ex.Message}");
                LogDestination = LogDestination.File;
                LogPath = defaultLogPath;
            }

            // Asegurar que el archivo de logs existe
            try
            {
                if (!File.Exists(LogPath))
                {
                    File.WriteAllText(LogPath, string.Empty);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error inicializando archivo de logs: {ex.Message}");
            }
        }
    }
}