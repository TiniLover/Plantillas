using BLL;
using DAL;
using Domain;

namespace Services
{
    public static class LogManagerFactory
    {
        public static ILogManager CreateLogManager(LogDestination destination, string pathOrConnString)
        {
            ILogRepository repository;

            switch (destination)
            {
                case LogDestination.File:
                    repository = new TextFileLogRepository(pathOrConnString);
                    break;
                case LogDestination.SQL:
                    repository = new ClientLoggerAdapter(new ClientLogger(pathOrConnString));
                    break;
                default:
                    throw new NotSupportedException($"Destination {destination} is not supported");
            }

            var logManager = new LogManager(repository);
            return new NotificationLogManagerDecorator(logManager);
        }
    }
}