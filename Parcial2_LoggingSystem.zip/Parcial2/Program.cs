using Services;
using System;
using System.Linq;
using System.IO;

namespace Parcial2
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Iniciando sistema de logging...");

            try
            {
                ApplicationSettings.InitializeConfiguration();
                Console.WriteLine($"Configuración cargada. Destino: {ApplicationSettings.LogDestination}");
                Console.WriteLine($"Ruta de logs: {Path.GetFullPath(ApplicationSettings.LogPath)}");

                var logManager = LogManagerFactory.CreateLogManager(
                    ApplicationSettings.LogDestination,
                    ApplicationSettings.LogPath);

                var loggingService = new LoggingService(logManager);

                loggingService.Log("Mensaje de información normal");
                loggingService.Log("Error crítico: CriticalError en el módulo X");
                loggingService.Log("Error fatal: FatalError en el sistema");

                Console.WriteLine("\nTodos los logs:");
                foreach (var log in loggingService.GetAllLogs().Take(10))
                {
                    Console.WriteLine(log.ToString());
                }

                Console.WriteLine($"\nTotal de logs: {loggingService.GetAllLogs().Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fatal: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }

            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();
        }
    }
}