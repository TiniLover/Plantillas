using DAL;
using Domain;
using System.Collections.Generic;

namespace BLL
{
    public class LogManager : ILogManager
    {
        private readonly ILogRepository _logRepository;

        public LogManager(ILogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public void LogMessage(string message)
        {
            var log = new Log { Message = message };
            _logRepository.AddLog(log);
        }

        public List<Log> GetAllLogs()
        {
            return _logRepository.GetAllLogs();
        }
    }
}