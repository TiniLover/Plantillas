using Domain;
using System;
using System.Collections.Generic;

namespace BLL
{
    public class NotificationLogManagerDecorator : ILogManager
    {
        private readonly ILogManager _logManager;

        public NotificationLogManagerDecorator(ILogManager logManager)
        {
            _logManager = logManager;
        }

        public void LogMessage(string message)
        {
            CheckForCriticalErrors(message);
            _logManager.LogMessage(message);
        }

        public List<Log> GetAllLogs()
        {
            return _logManager.GetAllLogs();
        }

        private void CheckForCriticalErrors(string message)
        {
            if (message.Contains("CriticalError"))
            {
                Console.WriteLine($"Enviando email a soporteNivel1@email.com: {message}");
            }

            if (message.Contains("FatalError"))
            {
                Console.WriteLine($"Enviando email a soporteNivel2@email.com: {message}");
            }
        }
    }
}