using Domain;
using System.Collections.Generic;

namespace DAL
{
    public interface ILogRepository
    {
        void AddLog(Log log);
        List<Log> GetAllLogs();
    }
}