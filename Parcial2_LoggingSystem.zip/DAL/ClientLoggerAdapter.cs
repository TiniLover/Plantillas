using Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAL
{
    public class ClientLogger
    {
        private readonly List<string> _logs = new List<string>();
        private readonly string _connectionInfo;

        public ClientLogger(string connectionInfo)
        {
            _connectionInfo = connectionInfo;
        }

        public void Write(string message)
        {
            _logs.Add(message);
        }

        public string[] ReadAll()
        {
            return _logs.ToArray();
        }
    }

    public class ClientLoggerAdapter : ILogRepository
    {
        private readonly ClientLogger _clientLogger;

        public ClientLoggerAdapter(ClientLogger clientLogger)
        {
            _clientLogger = clientLogger;
        }

        public void AddLog(Log log)
        {
            _clientLogger.Write(log.Message);
        }

        public List<Log> GetAllLogs()
        {
            return _clientLogger.ReadAll()
                .Select(msg => new Log { Message = msg })
                .ToList();
        }
    }
}