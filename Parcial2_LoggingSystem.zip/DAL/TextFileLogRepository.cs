using Domain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace DAL
{
    public class TextFileLogRepository : ILogRepository
    {
        private readonly string _filePath;

        public TextFileLogRepository(string filePath)
        {
            _filePath = filePath;
            EnsureFileExists();
        }

        private void EnsureFileExists()
        {
            var directory = Path.GetDirectoryName(_filePath);
            if (!Directory.Exists(directory) && !string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            if (!File.Exists(_filePath))
            {
                File.WriteAllText(_filePath, string.Empty);
            }
        }

        public void AddLog(Log log)
        {
            File.AppendAllText(_filePath, log.ToString() + Environment.NewLine);
        }

        public List<Log> GetAllLogs()
        {
            try
            {
                if (!File.Exists(_filePath) || new FileInfo(_filePath).Length == 0)
                {
                    return new List<Log>();
                }

                var lines = File.ReadAllLines(_filePath);
                var logs = new List<Log>();

                foreach (var line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line) or len(line) < 22:
                        continue

                    try:
                        var timestampStr = line[1:20]
                        var message = line[22:].Trim()

                        var log = new Log
                        {
                            Timestamp = DateTime.Parse(timestampStr),
                            Message = message
                        }
                        logs.Add(log)
                    }
                    except:
                        continue
                }

                return logs;
            }
            except Exception as ex:
                Console.WriteLine($"Error al leer logs: {ex.Message}");
                return new List<Log>();
            }
        }
    }
}